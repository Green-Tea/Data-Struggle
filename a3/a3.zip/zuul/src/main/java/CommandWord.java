public enum CommandWord {
    QUIT, HELP, GO, LOOK, UNKNOWN;

}
